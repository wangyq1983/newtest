/**
 * Created by Administrator on 2018/1/19.
 */
$(function () {
    $(".position-details-name").on('click',function () {
        $(this).siblings(".position-details-profile").slideToggle();
        $(this).children(".position-plus").toggleClass("nn");
        $(this).children(".position-less").toggleClass("nn");
    });
    $(".join-position span").on('click',function () {
        $(this).addClass('join-position-check').siblings().removeClass('join-position-check');
    });
    // 合作案例、新闻中心等点击左侧
    $(".classification").on('click',function () {
        $(this).addClass('vertical-bar-red').siblings().removeClass('vertical-bar-red');
        var index = $(this).index();
        $('.cooper-case').eq(index).show().siblings().hide();
    });
    // 加入我们
    $(".job").on('click',function () {
        var index = $(this).index();
        $('.position-list').eq(index).show().siblings().hide();
    });
});
